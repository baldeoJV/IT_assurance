<?php
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "travel_database";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Function to sanitize input
    function sanitize_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Process form submission
        $results = null;
        $all_results = [];

        // Get and sanitize form inputs
        error_reporting(0);
        $vacation_preference = sanitize_input($_POST['vacation_preference_q1']);
        $activity_preference = sanitize_input($_POST['activity_preference_q2']);
        $trip_pace = sanitize_input($_POST['trip_pace_q3']);
        $accommodation_budget = sanitize_input($_POST['accommodation_budget_q4']);
        $activity_budget = sanitize_input($_POST['activity_budget_q5']);
        $environment_preference = sanitize_input($_POST['environment_preference_q6']);
        $location_preference = sanitize_input($_POST['location_preference_q7']);
        $transport_preference = sanitize_input($_POST['transport_preference_q8']); 

        // Debug: Print sanitized input values
        // echo "<br><br>";
        // echo "Vacation Preference: $vacation_preference<br>";
        // echo "Activity Preference: $activity_preference<br>";
        // echo "Trip Pace: $trip_pace<br>";
        // echo "Accommodation Budget: $accommodation_budget<br>";
        // echo "Activity Budget: $activity_budget<br>";
        // echo "Environment Preference: $environment_preference<br>";
        // echo "Location Preference: $location_preference<br>";
        // echo "Transport Preference: $transport_preference<br><br>";

        $cities = array("palawanattractions", "cebuattractions", "boholattractions", "davaoattractions", "boracayattractions");

        foreach ($cities as $city) {
            // print_r($city);
            // echo "<br>";
            // echo "<br>";

            // Build the SQL query with filters
            $sql = "WITH city_accomodation_union AS (
                SELECT $city.AttractionID, accomodations.City, $city.Municipality, $city.Attraction, $city.PopularSecluded, $city.Budget, accomodations.Cost, accomodations.Type
                FROM $city
                JOIN accomodations
                ON $city.Municipality = accomodations.Municipality
                )

                SELECT city_accomodation_union.AttractionID, city_accomodation_union.City, city_accomodation_union.Municipality, city_accomodation_union.Attraction, city_accomodation_union.PopularSecluded, city_accomodation_union.Type,
                    activities.ActivityName, activities.Profile, activities.TravelerPreference, activities.Pacing, activities.Environment, activities.Transportation, activities.Fee, city_accomodation_union.Cost
                FROM city_accomodation_union
                JOIN activities
                ON city_accomodation_union.AttractionID = activities.AttractionID
                WHERE 1=1";

            //Q1 Profile (activities)
            if ($vacation_preference) {
                $sql .= " AND activities.Profile LIKE '%$vacation_preference%'";
            }
            
            // Q2 Travel Preference (activities)
            if ($activity_preference) {
                $sql .= " AND activities.TravelerPreference LIKE '%$activity_preference%'";
            }
        
            // Q3 Pacing (activities)
            if ($trip_pace) {
                $sql .= " AND activities.Pacing LIKE '%$trip_pace%'";
            }

            // Q4 Accommodation Budget (attractions)
            if ($accommodation_budget) {
                $sql .= " AND city_accomodation_union.Type LIKE '%$accommodation_budget%'";
            }

            // Q5: Convert activity budget to price ranges
            $max_fee = 0;
            switch($activity_budget) {
                case 'Very budget friendly':
                    $max_fee = 1000;
                    break;
                case 'Moderate':
                    $max_fee = 2500;
                    break;
                case 'Higher end':
                    $max_fee = 999999;
                    break;
            }

            if ($max_fee > 0) {
                $sql .= " AND activities.Fee <= $max_fee";
            }

            // Q6: Environment (activities)
            if ($environment_preference) {
                $sql .= " AND activities.Environment LIKE '%$environment_preference%'";
            }
        
            // Q7: Popularity (city)
            if ($location_preference) {
                $sql .= " AND city_accomodation_union.PopularSecluded LIKE '%$location_preference%'";
            }

            // Q8: Transportation (activities)
            if ($transport_preference) {
                $sql .= " AND activities.Transportation LIKE '%$transport_preference%'";
            }

            $sql .= " ORDER BY RAND() LIMIT 10";


            // Debug: Print the SQL query
            // echo "SQL Query: " . $sql . "<br><br>";

            // Execute query
            $results = $conn->query($sql);
            // print_r($results);

            if ($results && $results->num_rows > 0) {
                while ($row = $results->fetch_assoc()) {
                    $all_results[] = $row; // Store all rows from all cities
                }
            }      
            
            // print_r(count($all_results));  
            // echo "<br>";
            // echo "<br>";
        } 

        if (empty($all_result)) {

            echo "<p>No Match. You might be interested with these: </p>";

            foreach ($cities as $city) {
                // print_r($city);
                // echo "<br>";
                // echo "<br>";
        
                // Build the SQL query with filters
                $sql = "WITH city_accomodation_union AS (
                    SELECT $city.AttractionID, accomodations.City, $city.Municipality, $city.Attraction, $city.PopularSecluded, $city.Budget, accomodations.Cost, accomodations.Type
                    FROM $city
                    JOIN accomodations
                    ON $city.Municipality = accomodations.Municipality
                    )
        
                    SELECT city_accomodation_union.AttractionID, city_accomodation_union.City, city_accomodation_union.Municipality, city_accomodation_union.Attraction, city_accomodation_union.PopularSecluded, city_accomodation_union.Type,
                        activities.ActivityName, activities.Profile, activities.TravelerPreference, activities.Pacing, activities.Environment, activities.Transportation, activities.Fee, city_accomodation_union.Cost
                    FROM city_accomodation_union
                    JOIN activities
                    ON city_accomodation_union.AttractionID = activities.AttractionID
                    WHERE 1=1";
        
                //Q1 Profile (activities)
                if ($vacation_preference) {
                    $sql .= " AND activities.Profile LIKE '%$vacation_preference%'";
                }
                
            
                // Q7: Popularity (city)
                if ($location_preference) {
                    $sql .= " AND city_accomodation_union.PopularSecluded LIKE '%$location_preference%'";
                }
        
        
                $sql .= " ORDER BY RAND() LIMIT 10";
        
        
                // Debug: Print the SQL query
                // echo "SQL Query: " . $sql . "<br><br>";
        
                // Execute query
                $results = $conn->query($sql);
                // print_r($results);
        
                if ($results && $results->num_rows > 0) {
                    while ($row = $results->fetch_assoc()) {
                        $all_results[] = $row; // Store all rows from all cities
                    }
                }      
                
                // print_r(count($all_results));  
                // echo "<br>";
                // echo "<br>";
            } 

        }
    }
?>


<!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
            <title>Travel</title>
            <meta name="description" content="">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="apple-touch-icon" href="apple-touch-icon.png">

            <link rel="stylesheet" href="css/bootstrap.min.css">
            <link rel="stylesheet" href="css/fontAwesome.css">
            <link rel="stylesheet" href="css/hero-slider.css">
            <link rel="stylesheet" href="css/templatemo-main.css">
            <link rel="stylesheet" href="css/owl-carousel.css">

            <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

            <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
        </head>

        <body>

            <div class="fixed-side-navbar">
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link" href="#home"><span>Intro</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#services"><span>Questions</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#portfolio"><span>Results</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#our-story"><span>Extra</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact-us"><span>Contact Us</span></a></li>
                </ul>
            </div>

            <div class="parallax-content baner-content" id="home">
                <div class="adminButton">
                    <button onclick="window.location.href='admin.php'">Admin</button>
                </div>
                <div class="first-content-container">
                    <div class="first-content-header">
                        <div>
                            
                        </div>
                    </div>
                    <div class="first-content">
                        <div class="first-content-left">
                            <h1>Love the Philippines</h1>
                            <span>Tara na sa pilipinas!</span>
                            <div class="primary-button">
                                <a href="#services">Discover More</a>
                            </div>
                        </div>
                        
                        <div class="first-content-right">
                            <div class="box-container">
                                <div class="box">
                                    <p>Palawan <br> <strong>Philippines</strong></p>
                                </div>
                                <p class="description">Palawan is a stunning province in the Philippines that offers visitors a chance to explore some of the most beautiful natural wonders in the world.</p>
                            </div>
                            <div class="box-container">
                                <div class="box">
                                    <p>Bohol <br> <strong>Philippines</strong></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="service-content" id="services">
                <div class="form-container">
                    <form>
                        <!-- Question 1 -->
                        <div class="question-box">
                            <h3>Question 1</h3>
                            <p>How do you prefer to spend your vacation?</p>
            
                            <div class="options-container">
                                <div class="option">
                                    <input type="radio" id="q1-adventure" name="vacation_preference_q1" value="Adventure">
                                    <label for="q1-adventure">Adventure and activities (e.g. hiking, scuba diving)</label>
                                </div>
                        
                                <div class="option">
                                    <input type="radio" id="q1-relax" name="vacation_preference_q1" value="Relaxation">
                                    <label for="q1-relax">Relaxing on the beach/spa</label>
                                </div>
                        
                                <div class="option">
                                    <input type="radio" id="q1-culture" name="vacation_preference_q1" value="Culture">
                                    <label for="q1-culture">Cultural experiences</label>
                                </div>
                        
                                <div class="option">
                                    <input type="radio" id="q1-city" name="vacation_preference_q1" value="City">
                                    <label for="q1-city">City exploration</label>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Question 2 -->
                        <div class="question-box">
                            <h3>Question 2</h3>
                            <p>How do you feel about trying new and challenging activities?</p>
            
                            <div class="options-container">
                                <div class="option">
                                    <input type="radio" id="q2-open" name="activity_preference_q2" value="Very open, the more exciting the better">
                                    <label for="q2-open">Very open, the more exciting the better</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q2-moderate" name="activity_preference_q2" value="I prefer moderate activities, nothing too extreme">
                                    <label for="q2-moderate">I prefer moderate activities, nothing too extreme</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q2-relaxed" name="activity_preference_q2" value="I prefer laid back, relaxing experience">
                                    <label for="q2-relaxed">I prefer laid back, relaxing experience</label>
                                </div>
                            </div>
                        </div>
            
                        <!-- Question 3 -->
                        <div class="question-box">
                            <h3>Question 3</h3>
                            <p>What pace would you prefer for your trip?</p>
            
                            <div class="options-container">
                                <div class="option">
                                    <input type="radio" id="q3-fast" name="trip_pace_q3" value="Fast paced, exploring as much as possible">
                                    <label for="q3-fast">Fast paced, exploring as much as possible</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q3-balanced" name="trip_pace_q3" value="Balanced, mixing sightseeing with relaxation">
                                    <label for="q3-balanced">Balanced, mixing sightseeing with relaxation</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q3-slow" name="trip_pace_q3" value="Slow-paced, taking time to enjoy each place">
                                    <label for="q3-slow">Slow-paced, taking time to enjoy each place</label>
                                </div>
                            </div>
                        </div>
            
                        <!-- Question 4 -->
                        <div class="question-box">
                            <h3>Question 4</h3>
                            <p>What is your preferred budget for accommodation?</p>
            
                            <div class="options-container">
                                <div class="option">
                                    <input type="radio" id="q4-budget" name="accommodation_budget_q4" value="Budget">
                                    <label for="q4-budget">Budget (hostels, budget hotels, cabins, glamping tents)</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q4-midrange" name="accommodation_budget_q4" value="Mid-range">
                                    <label for="q4-midrange">Mid-range (3 star hotel, local guest house)</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q4-luxury" name="accommodation_budget_q4" value="Luxury">
                                    <label for="q4-luxury">Luxury (4-5 star hotel / resorts)</label>
                                </div>
                            </div>
                        </div>
            
                        <!-- Question 5 -->
                        <div class="question-box">
                            <h3>Question 5</h3>
                            <p>What is your ideal budget for activities?</p>
            
                            <div class="options-container">
                                <div class="option">
                                    <input type="radio" id="q5-budget" name="activity_budget_q5" value="Very budget friendly">
                                    <label for="q5-budget">Very budget friendly (mostly free or low cost activities)</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q5-moderate" name="activity_budget_q5" value="Moderate">
                                    <label for="q5-moderate">Moderate (mix of free, low cost and a few paid activities)</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q5-luxury" name="activity_budget_q5" value="Higher end">
                                    <label for="q5-luxury">Higher end (luxury activities and experience)</label>
                                </div>
                            </div>
                        </div>
            
                        <!-- Question 6 -->
                        <div class="question-box">
                            <h3>Question 6</h3>
                            <p>What kind of environment do you prefer?</p>
            
                            <div class="options-container">
                                <div class="option">
                                    <input type="radio" id="q6-nature" name="environment_preference_q6" value="Nature & outdoors">
                                    <label for="q6-nature">Nature & outdoors (mountains, beaches, national parks)</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q6-urban" name="environment_preference_q6" value="Urban">
                                    <label for="q6-urban">Urban (cities, shopping, nightlife)</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q6-historical" name="environment_preference_q6" value="Historical">
                                    <label for="q6-historical">Historical (heritage sites, museums)</label>
                                </div>
                            </div>
                        </div>
            
                        <!-- Question 7 -->
                        <div class="question-box">
                            <h3>Question 7</h3>
                            <p>Do you prefer a more touristy or secluded location?</p>
            
                            <div class="options-container">
                                <div class="option">
                                    <input type="radio" id="q7-popular" name="location_preference_q7" value="Popular">
                                    <label for="q7-popular">Popular</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q7-secluded" name="location_preference_q7" value="Off the beaten path">
                                    <label for="q7-secluded">Off the beaten path</label>
                                </div>
                            </div>
                        </div>
            
                        <!-- Question 8 -->
                        <div class="question-box">
                            <h3>Question 8</h3>
                            <p>How do you prefer to get around the destination?</p>
            
                            <div class="options-container">
                                <div class="option">
                                    <input type="radio" id="q8-car" name="transport_preference_q8" value="Rent a car or motorbike">
                                    <label for="q8-car">Rent a car or motorbike</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q8-public" name="transport_preference_q8" value="Public transport">
                                    <label for="q8-public">Public transport</label>
                                </div>
            
                                <div class="option">
                                    <input type="radio" id="q8-private" name="transport_preference_q8" value="Private transfers">
                                    <label for="q8-private">Private transfers</label>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- Submit Button -->
                    <button class="submit-button" role="submit">Submit</button>
                </div>
            </div>


            <div class="tabs-content" id="our-story">

                 <!-- Results Section -->
                    
                 <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
                        <div class="results-section">
                            <h2>Recommended Activities Based on Your Preferences</h2>
                            <?php if (!empty($all_results)): ?>
                                <?php 
                                $grouped_results = [];
                                foreach ($all_results as $row) {
                                    $grouped_results[$row['City']][] = $row;
                                }
                                ?>
                                <?php foreach ($grouped_results as $city_place => $results): ?>
                                    <div class="city-results">
                                        <!-- button for each city -->
                                        <button onclick="window.location.href='email.php'" 
                                            style="
                                                align-items: center;
                                                background-color: #fff;
                                                border-radius: 12px;
                                                border: 1px solid #121212 !important;
                                                box-shadow: transparent 0 0 0 3px, rgba(18, 18, 18, .1) 0 6px 20px;
                                                box-sizing: border-box;
                                                color: #121212;
                                                cursor: pointer;
                                                display: inline-flex;
                                                flex: 1 1 auto;
                                                font-family: Inter, sans-serif;
                                                font-size: 1.2rem;
                                                font-weight: 700;
                                                justify-content: center;
                                                line-height: 1;
                                                margin: 0;
                                                outline: none;
                                                padding: 1rem 1.2rem;
                                                text-align: center;
                                                text-decoration: none;
                                                transition: box-shadow .2s, -webkit-box-shadow .2s;
                                                white-space: nowrap;
                                                border: 0;
                                                user-select: none;
                                                -webkit-user-select: none;
                                                touch-action: manipulation;">
                                                <?php echo $city_place; ?>
                                            </button>

                                        <!-- results container for each city -->
                                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; padding: 20px; margin-top: 30px;">
                                            <?php foreach ($results as $row): ?>
                                                <div style="border: 1px solid #ddd; border-radius: 8px; padding: 15px; background-color: #f9f9f9;">
                                                    <h3 style="margin: 0; font-size: 18px; color: #333;"><?php echo $row['ActivityName']; ?></h3>
                                                    <p style="margin: 5px 0;"><strong>Location:</strong> 
                                                        <?php echo ($row['Municipality'] ? $row['Municipality'] . " - " . $row['Attraction'] : "Various locations"); ?>
                                                    </p>
                                                    <p style="margin: 5px 0;"><strong>Type:</strong> <?php echo $row['Profile']; ?></p>
                                                    <p style="margin: 5px 0;"><strong>Environment:</strong> <?php echo $row['Environment']; ?></p>
                                                    <p style="margin: 5px 0;"><strong>Pace:</strong> <?php echo $row['Pacing']; ?></p>
                                                    <p style="margin: 5px 0;"><strong>Transportation:</strong> <?php echo $row['Transportation']; ?></p>
                                                    <p style="margin: 5px 0;"><strong>Fee:</strong> PHP <?php echo number_format($row['Fee'], 2); ?></p>
                                                    <p style="margin: 5px 0;"><strong>Accommodation Type:</strong> <?php echo $row['Type']; ?></p>
                                                    <p style="margin: 5px 0;"><strong>Accommodation Cost:</strong> PHP <?php echo number_format($row['Cost'], 2); ?></p>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>

                                    <hr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="no-results">

                                    <p>There are no matching result on your preferences.</p>
                                    <p>You might like these instead.</p>


                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                
            </div>


            <div class="parallax-content contact-content" id="contact-us">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="contact-form">
                                <div class="row">
                                    <form id="contact" action="" method="post">
                                        <div class="row">
                                            <div class="col-md-12">
                                            <fieldset>
                                                <input name="name" type="text" class="form-control" id="name" placeholder="Your name..." required="">
                                            </fieldset>
                                            </div>
                                            <div class="col-md-12">
                                            <fieldset>
                                                <input name="email" type="email" class="form-control" id="email" placeholder="Your email..." required="">
                                            </fieldset>
                                            </div>
                                            <div class="col-md-12">
                                            <fieldset>
                                                <textarea name="message" rows="6" class="form-control" id="message" placeholder="Your message..." required=""></textarea>
                                            </fieldset>
                                            </div>
                                            <div class="col-md-12">
                                            <fieldset>
                                                <button type="submit" id="form-submit" class="btn">Send Message</button>
                                            </fieldset>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="map">

                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1197183.8373802372!2d-1.9415093691103689!3d6.781986417238027!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdb96f349e85efd%3A0xb8d1e0b88af1f0f5!2sKumasi+Central+Market!5e0!3m2!1sen!2sth!4v1532967884907" width="100%" height="390" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <footer>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="primary-button">
                                <a href="#home">Back To Top</a>
                            </div>
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-google"></i></a></li>
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                            <p>Copyright &copy; 2019 Company Name 
                    
                            - Design: <a rel="nofollow noopener" href="https://templatemo.com"><em>TemplateMo</em></a></p>
                        </div>
                    </div>
                </div>
            </footer>



            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
                <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>
                <script src="js/vendor/bootstrap.min.js"></script>
                <script src="js/plugins.js"></script>
                <script src="js/main.js"></script>
                <script>
                    function openCity(cityName) {
                        var i;
                        var x = document.getElementsByClassName("city");
                        for (i = 0; i < x.length; i++) {
                        x[i].style.display = "none";  
                        }
                        document.getElementById(cityName).style.display = "block";  
                    }
            </script>

            <script>
                $(document).ready(function(){
                // Add smooth scrolling to all links
                $(".fixed-side-navbar a, .primary-button a").on('click', function(event) {

                    // Make sure this.hash has a value before overriding default behavior
                    if (this.hash !== "") {
                    // Prevent default anchor click behavior
                    event.preventDefault();

                    // Store hash
                    var hash = this.hash;

                    // Using jQuery's animate() method to add smooth page scroll
                    // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
                    $('html, body').animate({
                        scrollTop: $(hash).offset().top
                    }, 800, function(){
                
                        // Add hash (#) to URL when done scrolling (default click behavior)
                        window.location.hash = hash;
                    });
                    } // End if
                });
                });
            </script>

        </body>
    </html>

<?php
    // Close the database connection
    $conn->close();
?>